<?php

 $server="localhost";
 $user="root";
 $password="";

 $con = mysqli_connect($server,$user,$password);
 if(!$con){
     die("connection data fail");
 }
//  if(isset($_POST['name']) || isset($_POST('pass'))){
 $username=$_POST['name'];
 $password=$_POST['pass'];
 $sql="INSERT INTO `tlogin`.`list` (`name`, `pass`) VALUES ('$username', '$password')";
 //echo $sql;

         if($con->query($sql) == true){
           // echo "Successfully inserted";
         }
         else{
            echo "error: $sql <br> $con->error";
         }
        $con->close();
        

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transporter Login </title>
    <link rel="stylesheet" href="tlogin.css">
</head>
<body>
    <div class="login">
        <form action="tlogin.php" method="post">
            <h2>Log In</h2>
            <input type="text" name="name" placeholder="Enter Your Name"><br>
            <input type="password" name="pass" placeholder="Enter Your Password"><br>
            <button>LOG IN</button>
        </form>
    </div>
    <!-- <script>
        function welcome(){
            window.open("tmain.html")
        }
    </script> -->
</body>
</html>